WELCOME!

Special additional features:


1. Modularity - You can change every aspect of the game easily.

2. Classes seperation - We have created 3 Classes - 
	Game class
	Cube Class
	GUI class (Graphics objects)

3. Graphic features - All the board was designed with images and backgrounds, using the 'canvas' widget.
		      As a result, we added three image files to the submission

4. Graphic changes - After every selection of cube, it's background picture changes to the selected background.

5. Additional key - After the word is complete, by pressing right click the user can test it.

6. Logo - We have designed a Logo for our game - availible for you in the launch screen.

7. Instructions - Game instructions window at the beginning of the first game only.

8. Special Fonts - We have added special fonts to the texts in our game.


The game was designed by Or Katz and Michael Sichenko